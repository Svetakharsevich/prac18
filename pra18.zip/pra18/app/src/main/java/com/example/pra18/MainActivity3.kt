package com.example.pra18

import android.content.Intent
import android.content.SharedPreferences
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import android.widget.TextView

class MainActivity3 : AppCompatActivity() {
    private lateinit var listView: ListView
    private lateinit var clear: Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main3)
        clear = findViewById(R.id.delete)
        listView = findViewById(R.id.list_view)

        val tickets = SharedPreferencesHelper.loadTickets(this)
        val ticketData = tickets.map { "${it.number} - ${it.type}" }
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, ticketData)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        listView.adapter = adapter

        clear.setOnClickListener {
            SharedPreferencesHelper.clearTickets(this)
            adapter.clear()
            adapter.notifyDataSetChanged()
        }
    }

    fun newBilet(){
        val intent = Intent(this, MainActivity2::class.java)
        startActivity(intent)
    }
}
