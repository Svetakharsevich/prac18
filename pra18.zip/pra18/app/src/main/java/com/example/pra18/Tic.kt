package com.example.pra18

data class Tic(val number: String, val type: String)