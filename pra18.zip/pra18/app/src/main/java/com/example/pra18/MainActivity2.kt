package com.example.pra18

import android.content.Intent
import android.content.SharedPreferences
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity2 : AppCompatActivity() {
     lateinit var numeric: EditText
     lateinit var textw:EditText
     lateinit var save:Button
     lateinit var list:Button
    lateinit var sw:SharedPreferences
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)
        numeric=findViewById(R.id.numeric_b)
        textw=findViewById(R.id.textw)
        save=findViewById(R.id.button_save)
        list=findViewById(R.id.button_list)
        sw=getPreferences(MODE_PRIVATE)
        save.setOnClickListener{
            if (numeric.text.toString().isEmpty() || textw.text.toString().isEmpty()){
                val i = Toast.makeText(this, "Введите номер и тип билета.", Toast.LENGTH_SHORT)
                i.setGravity(Gravity.TOP, 0, 160)
                i.show()

            }
            else{
                val number = numeric.text.toString()
                val type = textw.text.toString()
                val tic = Tic(number, type)
                val tickets = SharedPreferencesHelper.loadTickets(this).toMutableList()
                tickets.add(tic)
                SharedPreferencesHelper.saveTickets(this, tickets)

                val i = Toast.makeText(this, "Билет № $number добавлен.", Toast.LENGTH_SHORT)
                i.setGravity(Gravity.TOP, 0, 160)
                i.show()

                numeric.text = null
                textw.text = null
            }

        }
        list.setOnClickListener{
            val intent = Intent(this, MainActivity3::class.java)
            startActivity(intent)
        }

    }
}